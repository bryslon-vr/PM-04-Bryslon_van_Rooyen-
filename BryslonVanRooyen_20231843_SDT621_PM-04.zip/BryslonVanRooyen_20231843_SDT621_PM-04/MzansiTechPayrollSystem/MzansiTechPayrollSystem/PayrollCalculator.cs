﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MzansiTechPayrollSystem
{
    public class PayrollCalculator
    {
        public double CalculateGrossPay(double hours) => hours * 950.00;
        public double CalculateUIF(double gross) => gross * 0.01;
        public double CalculateMembership(double gross) => gross * 0.13;
        public double CalculatePAYE(double gross, int dependents) => (gross - (gross * 0.0575 * dependents)) * 0.25;
        public double CalculateNetPay(double gross, double uif, double paye, double membership) => gross - (uif + paye + membership);
    }
}
