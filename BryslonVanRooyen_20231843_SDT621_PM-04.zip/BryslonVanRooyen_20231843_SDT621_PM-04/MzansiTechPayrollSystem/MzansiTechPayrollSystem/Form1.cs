﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MzansiTechPayrollSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // Validation Checks
            if (string.IsNullOrWhiteSpace(txtContractorName.Text))
            {
                MessageBox.Show("Contractor Name is required."); return;
            }
            if (!double.TryParse(txtHoursWorked.Text, out double hours) || hours < 0)
            {
                MessageBox.Show("Hours Worked must be a positive number."); return;
            }
            if (!int.TryParse(txtDependents.Text, out int deps) || deps < 0 || deps > 10)
            {
                MessageBox.Show("Dependents must be an integer between 0 and 10."); return;
            }

            // Processing Calculations
            PayrollCalculator calc = new PayrollCalculator();
            double gross = calc.CalculateGrossPay(hours);
            double uif = calc.CalculateUIF(gross);
            double member = calc.CalculateMembership(gross);
            double paye = calc.CalculatePAYE(gross, deps);
            double totalDeductions = uif + member + paye;
            double net = calc.CalculateNetPay(gross, uif, paye, member);

            // Binding Outputs to GUI Display Text Strings
            lblGrossPay.Text = gross.ToString("C");
            lblPAYE.Text = paye.ToString("C");
            lblUIF.Text = uif.ToString("C");
            lblMembershipFee.Text = member.ToString("C");
            lblTotalDeductions.Text = totalDeductions.ToString("C");
            lblNetPay.Text = net.ToString("C");

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtContractorName.Clear(); txtHoursWorked.Clear(); txtDependents.Clear();
            lblGrossPay.Text = ""; lblPAYE.Text = ""; lblUIF.Text = "";
            lblMembershipFee.Text = ""; lblTotalDeductions.Text = ""; lblNetPay.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
