﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MzansiTechPayrollSystem; // Links to your main project

namespace PayrollSystemTests
{
    [TestClass]
    public class PayrollTests
    {
        // Required by your rubric to output test execution details
        public TestContext TestContext { get; set; }

        [TestMethod]
        [TestCategory("Payroll Calculations")]
        public void TestGrossPayCalculation()
        {
            PayrollCalculator calc = new PayrollCalculator();
            double actual = calc.CalculateGrossPay(40);

            TestContext.WriteLine($"Gross Pay Actual: {actual}");
            Assert.AreEqual(38000.00, actual, 0.01);
        }

        [TestMethod]
        [TestCategory("Payroll Calculations")]
        public void TestUIFDeductionCalculation()
        {
            PayrollCalculator calc = new PayrollCalculator();
            double actual = calc.CalculateUIF(38000.00);

            TestContext.WriteLine($"UIF Actual: {actual}");
            Assert.AreEqual(380.00, actual, 0.01);
        }

        [TestMethod]
        [TestCategory("Payroll Calculations")]
        public void TestMembershipFeeCalculation()
        {
            PayrollCalculator calc = new PayrollCalculator();
            double actual = calc.CalculateMembership(38000.00);

            TestContext.WriteLine($"Membership Fee Actual: {actual}");
            Assert.AreEqual(4940.00, actual, 0.01);
        }

        [TestMethod]
        [TestCategory("Payroll Calculations")]
        public void TestPAYEDeductionCalculation()
        {
            PayrollCalculator calc = new PayrollCalculator();
            double actual = calc.CalculatePAYE(38000.00, 2);

            TestContext.WriteLine($"PAYE Actual: {actual}");
            Assert.AreEqual(8407.50, actual, 0.01);
        }

        [TestMethod]
        [TestCategory("Payroll Calculations")]
        public void TestNetPayCalculation()
        {
            PayrollCalculator calc = new PayrollCalculator();
            double gross = 38000.00;
            double uif = 380.00;
            double membership = 4940.00;
            double paye = 8407.50;

            // Calls your 4-argument method signature
            double actual = calc.CalculateNetPay(gross, uif, paye, membership);

            TestContext.WriteLine($"Net Pay Actual: {actual}");
            Assert.AreEqual(24272.50, actual, 0.01);
        }
    }
}