﻿using MzansiTechPayrollSystem;
namespace PayrollSystemTests

{
    [TestClass]
    public sealed class PayrollTests
    {
        public TestContext TestContext { get; set; }

        [TestMethod]
        [TestCategory("Payroll Calculations")] // Required Rubric Target Component
        public void TestGrossPayCalculation()
        {
            // Arrange
            PayrollCalculator calc = new PayrollCalculator();
            double grossPay = 38000.00;
            double uif = 380.00;
            double membership = 4940.00;
            double paye = 8407.50;
            double expectedNetPay = 24272.50; // 38000 - (380 + 4940 + 8407.50)

            // Act - CHANGE THIS LINE to pass all 4 variables:
            double actualNetPay = calc.CalculateNetPay(grossPay, uif, paye, membership);

            // Assert
            TestContext.WriteLine($"Expected Net Pay: {expectedNetPay}, Actual: {actualNetPay}");
            Assert.AreEqual(expectedNetPay, actualNetPay, 0.01);
        }
    }
}
